﻿namespace Module_Loader
{
    internal class Utils
    {
    }
}