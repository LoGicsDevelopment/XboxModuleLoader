﻿using JRPC_Client;
using System;
using System.Drawing;
using System.Windows.Forms;
using XDevkit;

namespace Module_Loader {
    public partial class Loader : Form {
        public static IXboxConsole xbCon;
        private static string[] SizeSuffixes;

        public Loader() {
            InitializeComponent();
            string[] strArrays = new string[] { "bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB" };
            SizeSuffixes = strArrays;
        }

        private void Loader_Load(object sender, EventArgs e) {

        }

        private static string SizeSuffix(long value) {
            string str;
            if (value < (long)0) {
                str = string.Concat("-", SizeSuffix(-value));
            }
            else if (value == (long)0) {
                str = "0.0 bytes";
            }
            else {
                int num = (int)Math.Log((double)value, 1024);
                decimal num1 = value / ((long)1 << (num * 10 & 63 & 63 & 63));
                str = string.Format("{0:n1} {1}", num1, SizeSuffixes[num]);
            }
            return str;
        }

        private void btnConnect_Click(object sender, EventArgs e) {
            if(xbCon.Connect(out xbCon)) {
                xbCon.XNotify("Module Loader Connected!");
            }
        }

        private void btnDisconnect_Click(object sender, EventArgs e) {

        }

        private void btnRefresh_Click(object sender, EventArgs e) {
            XBOX_MODULE_INFO moduleInfo;
            try {
                this.listModules.Items.Clear();
                IXboxDebugTarget debugTarget = xbCon.DebugTarget;
                try {
                    debugTarget.ConnectAsDebugger(xbCon.XboxIP(), XboxDebugConnectFlags.Force);
                }
                catch {

                }
                foreach (IXboxModule module in debugTarget.Modules) {
                    try {
                        try {
                            ListView.ListViewItemCollection items = this.listModules.Items;
                            ListViewItem listViewItem = new ListViewItem(module.ModuleInfo.FullName.ToString());
                            try {
                                ListViewItem.ListViewSubItemCollection subItems = listViewItem.SubItems;
                                moduleInfo = module.ModuleInfo;
                                subItems.Add(string.Concat("0x", moduleInfo.BaseAddress.ToString("X")));
                            }
                            catch {
                                listViewItem.SubItems.Add("Error");
                            }
                            try {
                                ListViewItem.ListViewSubItemCollection listViewSubItemCollections = listViewItem.SubItems;
                                uint entryPointAddress = module.GetEntryPointAddress();
                                listViewSubItemCollections.Add(string.Concat("0x", entryPointAddress.ToString("X")));
                            }
                            catch {
                                listViewItem.SubItems.Add("Error");
                            }
                            try {
                                long size = (long)module.ModuleInfo.Size;
                                listViewItem.SubItems.Add(SizeSuffix(size).ToString());
                            }
                            catch {
                                listViewItem.SubItems.Add("Error");
                            }
                            try {
                                ListViewItem.ListViewSubItemCollection subItems1 = listViewItem.SubItems;
                                int hashCode = module.GetHashCode();
                                subItems1.Add(hashCode.ToString());
                            }
                            catch {
                                listViewItem.SubItems.Add("Error");
                            }
                            try {
                                ListViewItem.ListViewSubItemCollection listViewSubItemCollections1 = listViewItem.SubItems;
                                moduleInfo = module.ModuleInfo;
                                listViewSubItemCollections1.Add(moduleInfo.CheckSum.ToString());
                            }
                            catch {
                                listViewItem.SubItems.Add("Error");
                            }
                            items.Add(listViewItem);
                        }
                        catch {

                        }
                    }
                    catch {

                    }
                }
                this.lblModules.Text = string.Concat(this.listModules.Items.Count);
                this.lblModules.ForeColor = Color.Green;
                xbCon.XNotify($"Modules Count: [{listModules.Items.Count}] ");
                try {
                    debugTarget.DisconnectAsDebugger();
                }
                catch {

                }
            }
            catch {

            }
        }

        private uint GetModuleHandle(string moduleName) {
            object[] objArray = new object[] { moduleName };
            return xbCon.Call<uint>("xam.xex", 1102, objArray);
        }

        private void UnloadImage(string mod, bool sysdll) {
            uint moduleHandle = this.GetModuleHandle(mod);
            if (moduleHandle != 0) {
                if (sysdll) {
                    xbCon.WriteInt16(moduleHandle + 64, 1);
                }
                object[] objArray = new object[] { moduleHandle };
                xbCon.CallVoid("xboxkrnl.exe", 417, objArray);
            }
        }

        private void btnUnload_Click(object sender, EventArgs e) {
            try {
                if (this.listModules.SelectedItems.Count > 0) {
                    UnloadImage(this.listModules.SelectedItems[0].SubItems[0].Text, true);
                    MessageBox.Show("Module now unloaded!", "Success");
                }
            }
            catch {
                MessageBox.Show("Error Unloading Module", "error");
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {

        }

        private void Loader_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }
    }
}